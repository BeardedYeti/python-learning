# 
# Example file for parsing and processing HTML
#


def main():
  # instantiate the parser and feed it some HTML
  parser = MyHTMLParser()
    

if __name__ == "__main__":
  main();
  