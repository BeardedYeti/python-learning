# Testing Python stack functions

# TODO: create a new empty stack
stack = []

# TODO: push items onto the stack
stack.append(1)
stack.append(2)
stack.append(3)
stack.append(4)

# TODO: print the stack contents
print(stack)

# TODO: pop an item off the stack
x = stack.pop()
print(x)
print(stack)